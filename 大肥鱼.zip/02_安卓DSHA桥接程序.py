#!/usr/bin/env python3
# DSHA (Ubuntu terminal) <-> existing Cloudflare Worker BigFish /agent bridge.
# Compatible protocol: /dsha/next + /dsha/complete in BigFish Worker v2.3.3.
# Python standard library only. No secrets in source code.
import json
import os
import shutil
import signal
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

WORKER_URL = os.environ.get('BIGFISH_WORKER_URL', '').strip().rstrip('/')
SECRET = os.environ.get('BIGFISH_BRIDGE_SECRET', '').strip()
POLL_SECONDS = max(5, int(os.environ.get('BIGFISH_POLL_SECONDS', '15')))
# Worker has a 120-second task lease. Finish with enough time to post response.
JOB_TIMEOUT = min(100, max(20, int(os.environ.get('BIGFISH_JOB_TIMEOUT', '100'))))
STOP = False

def stopping(*_):
    global STOP
    STOP = True

signal.signal(signal.SIGINT, stopping)
signal.signal(signal.SIGTERM, stopping)

def post_json(path, payload):
    body = json.dumps(payload, ensure_ascii=False).encode('utf-8')
    req = urllib.request.Request(
        WORKER_URL + path,
        data=body,
        headers={
            'Authorization': 'Bearer ' + SECRET,
            'Content-Type': 'application/json; charset=utf-8',
            'Accept': 'application/json'
        },
        method='POST',
    )
    with urllib.request.urlopen(req, timeout=25) as resp:
        data = json.loads(resp.read(1024 * 1024).decode('utf-8'))
    if not isinstance(data, dict) or not data.get('ok'):
        raise RuntimeError('Worker rejected request: ' + str(data)[:400])
    return data

def run_dsh(prompt):
    if not shutil.which('dsh'):
        return 'DSHA Ubuntu 中未找到 dsh 命令。请在内置 Ubuntu 终端执行本脚本，并确认 headless 可用。'
    try:
        finished = subprocess.run(
            ['dsh', '--profile', 'headless', '--permission-mode', 'read-only', '-'],
            input=prompt, text=True, capture_output=True, timeout=JOB_TIMEOUT,
            check=False,
        )
    except subprocess.TimeoutExpired:
        return f'本次 DSHA 任务超过 {JOB_TIMEOUT} 秒，已中止。请缩短任务后重试。'
    except Exception as exc:
        return '执行 DSHA 失败：' + str(exc)[:300]
    output = (finished.stdout or '').strip()
    if finished.returncode != 0:
        diagnostic = (finished.stderr or '').strip().splitlines()
        tail = '\n'.join(diagnostic[-3:])[-400:] if diagnostic else ''
        return 'DSHA 任务失败：' + (tail or '无错误详情')
    return output[:3700] or 'DSHA 没有返回文字结果。'

def main():
    global STOP
    parsed = urllib.parse.urlparse(WORKER_URL)
    if parsed.scheme != 'https' or not parsed.netloc or parsed.username or parsed.password:
        sys.exit('请设置 BIGFISH_WORKER_URL 为完整 HTTPS Worker 地址（不要包含 /telegram）。')
    if not SECRET:
        sys.exit('请设置 BIGFISH_BRIDGE_SECRET，与 Worker 的 AGENT_BRIDGE_SECRET 一致。')
    if not shutil.which('dsh'):
        sys.exit('找不到 dsh。请在 DSHA 的 Ubuntu 内置终端启动此脚本。')
    print(f'已启动大肥鱼 DSHA 桥接。每 {POLL_SECONDS} 秒检查一次；Ctrl+C 停止。', flush=True)
    print('注意：此桥接只处理 Telegram /agent 指令；主动消息需要 Worker Cron 功能。', flush=True)
    failures = 0
    while not STOP:
        try:
            response = post_json('/dsha/next', {})
            failures = 0
            job = response.get('job')
            if job:
                job_id = str(job.get('id', ''))
                lease = str(job.get('lease', ''))
                if not job_id or not lease:
                    raise RuntimeError('Missing job id/lease')
                print('接收到任务 ' + job_id[:8], flush=True)
                if job.get('deliverOnly'):
                    answer = str(job.get('answer') or 'DSHA 无结果。')
                else:
                    answer = run_dsh(str(job.get('prompt') or ''))
                result = post_json('/dsha/complete', {
                    'id': job_id,
                    'lease': lease,
                    'answer': answer[:3700],
                })
                print('已发送回 TG' if result.get('delivered') else 'Worker 已接收结果', flush=True)
                continue
        except urllib.error.HTTPError as exc:
            failures += 1
            msg = exc.read(200).decode('utf-8', 'replace')
            print(f'Worker HTTP {exc.code}: {msg}', flush=True)
            if exc.code in (401, 403):
                print('授权失败：核对 Secret，暂停避免重复失败。', flush=True)
                break
        except (urllib.error.URLError, TimeoutError, ValueError, RuntimeError) as exc:
            failures += 1
            print('通信失败：' + str(exc)[:300], flush=True)
        except Exception as exc:
            failures += 1
            print('运行异常：' + str(exc)[:300], flush=True)
        sleep_for = min(POLL_SECONDS * (2 ** min(failures, 3)), 120)
        for _ in range(sleep_for):
            if STOP:
                break
            time.sleep(1)
    print('DSHA 桥接已停止。', flush=True)

if __name__ == '__main__':
    main()
